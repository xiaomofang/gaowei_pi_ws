#include "Serial_Send.h"
#include <geometry_msgs/PointStamped.h>
#include "my_car/Speed.h"

#define AUTO_MODE 1
#define HAND_MODE 0

ros::Subscriber _mode_sub, _speed_sub;
Serial_Send_Msg * _send_msg = new Serial_Send_Msg();

int Ctl_Mode = HAND_MODE;
int8_t Auto_Speed[4];

int scanKeyboard(void);
void Speed_Set(int Key_Value);

void recClickedCallBack(const geometry_msgs::PointStamped::ConstPtr& msg) {

    Ctl_Mode = HAND_MODE;
}

void recSpeedCallBack(const my_car::Speed msg) {

    Auto_Speed[0] = msg.speed_0;
    Auto_Speed[1] = msg.speed_1;
    Auto_Speed[2] = msg.speed_2;
    Auto_Speed[3] = msg.speed_3;
}

int main(int argc, char **argv) {

    ros::init(argc, argv, "car_ctl");
    ros::NodeHandle nh;

    if(_send_msg->Serial_Open()) {
        ROS_INFO("Serial open success!");
    }
    else {
        ROS_ERROR("Serial open failed!");
        return -1;
    }

    _mode_sub = nh.subscribe("/clicked_point", 1, recClickedCallBack); 
    _speed_sub = nh.subscribe("/car_speed", 4, recSpeedCallBack);

    int Key_Value = 0;
    ros::Rate loop_rate(50);

    while(ros::ok())
    {   
        if(Ctl_Mode == HAND_MODE) {
            
            Speed_Set(scanKeyboard()); 
            ROS_INFO("Mode: %d", Ctl_Mode);
            
        }
        else {

            _send_msg->Send_Speed(Auto_Speed);
           
        }   
        
        ros::spinOnce();
        loop_rate.sleep();
    }

    _send_msg->Serial_Close();
    
    return -1;
}


void Speed_Set(int Key_Value) {

    int8_t speed[4];
    int set_speed = 10;

    switch(Key_Value) {

        case KEY_W:
            speed[0] = set_speed;
            speed[1] = set_speed;
            speed[2] = set_speed;
            speed[3] = set_speed;            
            break;
        case KEY_A:
            speed[0] = -set_speed;
            speed[1] = set_speed;
            speed[2] = set_speed;
            speed[3] = -set_speed;            
            break;
        case KEY_S:
            speed[0] = -set_speed;
            speed[1] = -set_speed;
            speed[2] = -set_speed;
            speed[3] = -set_speed;            
            break;
        case KEY_D:
            speed[0] = set_speed;
            speed[1] = -set_speed;
            speed[2] = -set_speed;
            speed[3] = set_speed;            
            break;
        case KEY_Q:
            speed[0] = -set_speed;
            speed[1] = -set_speed;
            speed[2] = set_speed;
            speed[3] = set_speed;              
            break;
        case KEY_E:
            speed[0] = set_speed;
            speed[1] = set_speed;
            speed[2] = -set_speed;
            speed[3] = -set_speed;              
            break;            
        case KEY_X:
            speed[0] = 0;
            speed[1] = 0;
            speed[2] = 0;
            speed[3] = 0;     
            break;       
        case KEY_O:
            Ctl_Mode = AUTO_MODE;
            break; 
    }

    _send_msg->Send_Speed(speed);

}

int scanKeyboard(void)
{
    int in;
    struct termios new_settings;
    struct termios stored_settings;
    tcgetattr(0,&stored_settings);
    new_settings = stored_settings;
    new_settings.c_lflag &= (~ICANON);
    new_settings.c_cc[VTIME] = 0;
    tcgetattr(0,&stored_settings);
    new_settings.c_cc[VMIN] = 1;
    tcsetattr(0,TCSANOW,&new_settings);
    
    in = getchar();
    
    tcsetattr(0,TCSANOW,&stored_settings);
    return in;
}
